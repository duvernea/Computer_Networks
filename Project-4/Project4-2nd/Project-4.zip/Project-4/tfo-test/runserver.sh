#!/bin/sh

python server.py 127.0.0.1 8080 test.txt 1
