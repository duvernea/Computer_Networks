echo 3 | sudo tee /proc/sys/net/ipv4/tcp_fastopen
