echo 0 | sudo tee /proc/sys/net/ipv4/tcp_fastopen
